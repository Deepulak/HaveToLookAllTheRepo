export const theme = {
  breakpoints: {
    lg: "64rem",
    md: "58.125rem",
    sm: "48rem",
    xs: "31.25rem",
  },
};
