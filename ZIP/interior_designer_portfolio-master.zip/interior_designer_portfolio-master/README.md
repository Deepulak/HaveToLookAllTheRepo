# Interior designer portfolio

## Description

The project is an example of designer portfolio, with the following features:
- About page with general information about designer and his experience
- Gallery of works, where you can read about each and order it
- Appointment calender, where you can make appointment with designer

## Technologies
- React.js frontend framework
- Redux.js state managment tool
- Scss preprocesssor
- Firebase as deploy platform
- Firestore database
- Cloudinary as media storage
